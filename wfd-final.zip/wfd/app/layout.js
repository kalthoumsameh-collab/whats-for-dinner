export const metadata = {
  title: "What's for Dinner?",
  description: "Tell us what you have. We'll handle the rest.",
  viewport: "width=device-width, initial-scale=1, maximum-scale=1",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        <link
          href="https://fonts.googleapis.com/css2?family=Lora:ital,wght@0,400;0,700;1,400&display=swap"
          rel="stylesheet"
        />
      </head>
      <body style={{ margin: 0, padding: 0, background: "#fdf8f0" }}>
        {children}
      </body>
    </html>
  );
}
