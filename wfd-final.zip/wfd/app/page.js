import WFDApp from "../components/WFDApp";

export default function Home() {
  return <WFDApp />;
}
