"use client";

import { useState, useRef, useEffect } from "react";

const MODES = [
  { id: "normal",   emoji: "🍽️", label: "Just Hungry",  desc: "Whatever sounds good" },
  { id: "broke",    emoji: "💸", label: "I'm Broke",     desc: "Under £3, budget shops" },
  { id: "noenergy", emoji: "😴", label: "No Energy",     desc: "Under 10 mins, low effort" },
  { id: "gym",      emoji: "💪", label: "Gym Mode",      desc: "High protein, fitness goals" },
  { id: "expiring", emoji: "⚠️", label: "Use It Up",     desc: "Save food going off soon" },
];
const DIETS    = ["None", "Vegan", "Halal", "Gluten-Free", "Nut-Free", "Dairy-Free"];
const PORTIONS = [1, 2, 3, 4, 6];
const TAG_META = {
  "💸 Budget":       { bg: "#fef3c7", color: "#92400e", border: "#fde68a" },
  "⚡ Quick":        { bg: "#d1fae5", color: "#065f46", border: "#a7f3d0" },
  "💪 High Protein": { bg: "#dbeafe", color: "#1e3a8a", border: "#bfdbfe" },
  "🌱 Vegan":        { bg: "#dcfce7", color: "#14532d", border: "#bbf7d0" },
  "🕌 Halal":        { bg: "#ede9fe", color: "#4c1d95", border: "#ddd6fe" },
  "🚫 Gluten-Free":  { bg: "#fee2e2", color: "#7f1d1d", border: "#fecaca" },
  "🌍 World":        { bg: "#cffafe", color: "#164e63", border: "#a5f3fc" },
  "🔥 Spicy":        { bg: "#ffedd5", color: "#7c2d12", border: "#fed7aa" },
};
const DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
const CUISINES = [
  { name: "Japanese",  flag: "🇯🇵", dish: "Gyoza",           fact: "Japan has over 100 distinct noodle dish styles." },
  { name: "Mexican",   flag: "🇲🇽", dish: "Tacos al Pastor",  fact: "Mexico has the most UNESCO-recognised traditional foods." },
  { name: "Moroccan",  flag: "🇲🇦", dish: "Tagine",           fact: "Moroccan meals traditionally begin with bread, olives & argan oil." },
  { name: "Thai",      flag: "🇹🇭", dish: "Pad Thai",         fact: "Thai food balances 5 flavours: sweet, sour, salty, bitter, spicy." },
  { name: "Indian",    flag: "🇮🇳", dish: "Butter Chicken",   fact: "India has the world's largest vegetarian population." },
  { name: "Italian",   flag: "🇮🇹", dish: "Cacio e Pepe",     fact: "There are over 350 distinct pasta shapes in Italy." },
  { name: "Korean",    flag: "🇰🇷", dish: "Bibimbap",         fact: "Kimchi is eaten at almost every Korean meal, every day." },
];

function Logo({ size = 56 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 100 100" fill="none">
      <circle cx="50" cy="50" r="48" fill="#1e120a" />
      <circle cx="50" cy="50" r="43" fill="none" stroke="#c17f3a" strokeWidth="1.2" />
      <circle cx="50" cy="50" r="40" fill="none" stroke="#e8903a" strokeWidth="0.6" />
      <circle cx="50" cy="9"  r="1.8" fill="#e8903a" />
      <circle cx="50" cy="91" r="1.8" fill="#e8903a" />
      <circle cx="9"  cy="50" r="1.8" fill="#e8903a" />
      <circle cx="91" cy="50" r="1.8" fill="#e8903a" />
      <polyline points="22,34 29,66 37,46 45,66 52,34"
        fill="none" stroke="white" strokeWidth="5.5"
        strokeLinejoin="round" strokeLinecap="round" />
      <path d="M57 34 L57 66 Q82 66 82 50 Q82 34 57 34Z"
        fill="none" stroke="#e8903a" strokeWidth="5"
        strokeLinejoin="round" strokeLinecap="round" />
      <line x1="54" y1="38" x2="54" y2="62" stroke="#c17f3a" strokeWidth="0.8" opacity="0.5" />
    </svg>
  );
}

function Tag({ label }) {
  const m = TAG_META[label] || { bg: "#fef3c7", color: "#92400e", border: "#fde68a" };
  return <span style={{ padding: "3px 10px", borderRadius: 999, fontSize: 11, fontWeight: "700", background: m.bg, color: m.color, border: `1px solid ${m.border}` }}>{label}</span>;
}
function SLabel({ children, style = {} }) {
  return <p style={{ fontSize: 10, letterSpacing: "2px", color: "#a89070", fontWeight: "700", textTransform: "uppercase", marginBottom: 10, marginTop: 0, ...style }}>{children}</p>;
}
function Card({ children, style = {}, onClick }) {
  return <div onClick={onClick} style={{ background: "#fff", borderRadius: 20, border: "1.5px solid #ede5d5", boxShadow: "0 2px 12px #c8a97815", cursor: onClick ? "pointer" : "default", ...style }}>{children}</div>;
}
function Stars({ value, onChange }) {
  return (
    <div style={{ display: "flex", gap: 3 }}>
      {[1, 2, 3, 4, 5].map(n => (
        <span key={n} onClick={() => onChange && onChange(n)}
          style={{ fontSize: 20, cursor: onChange ? "pointer" : "default", color: n <= value ? "#e8903a" : "#e8d5b0", transition: "color .15s" }}>★</span>
      ))}
    </div>
  );
}
function PillBtn({ active, onClick, children }) {
  return <button onClick={onClick} style={{ padding: "8px 15px", borderRadius: 999, fontFamily: "inherit", fontSize: 13, cursor: "pointer", border: active ? "2px solid #c17f3a" : "1.5px solid #e8d5b0", background: active ? "#fef3e2" : "#fff", color: active ? "#92400e" : "#9a8068", fontWeight: active ? "700" : "400", transition: "all .18s" }}>{children}</button>;
}

function useLocalStorage(key, initial) {
  const [val, setVal] = useState(initial);
  const [ready, setReady] = useState(false);
  useEffect(() => {
    try { const s = localStorage.getItem(key); if (s) setVal(JSON.parse(s)); } catch {}
    setReady(true);
  }, [key]);
  const set = (newVal) => {
    const v = typeof newVal === "function" ? newVal(val) : newVal;
    setVal(v);
    try { localStorage.setItem(key, JSON.stringify(v)); } catch {}
  };
  return [val, set, ready];
}

export default function WFDApp() {
  const [tab, setTab]               = useState("find");
  const [ingredients, setIngredients] = useState("");
  const [expiring, setExpiring]     = useState("");
  const [mode, setMode]             = useState("normal");
  const [diet, setDiet]             = useState("None");
  const [portions, setPortions]     = useState(2);
  const [loading, setLoading]       = useState(false);
  const [meals, setMeals]           = useState(null);
  const [expanded, setExpanded]     = useState(null);
  const [error, setError]           = useState("");
  const [cooking, setCooking]       = useState(null);
  const [planTarget, setPlanTarget] = useState(null);
  const [photoName, setPhotoName]   = useState(null);
  const [photoLoading, setPhotoLoading] = useState(false);
  const [saveToast, setSaveToast]   = useState("");

  const [favourites, setFavourites, favReady] = useLocalStorage("wfd:favourites", []);
  const [ratings,    setRatings]              = useLocalStorage("wfd:ratings",    {});
  const [planner,    setPlanner]              = useLocalStorage("wfd:planner",    {});
  const [shopList,   setShopList,  shopReady] = useLocalStorage("wfd:shoplist",   []);
  const [streak,     setStreak]               = useLocalStorage("wfd:streak",     0);

  const cuisine = CUISINES[new Date().getDay() % CUISINES.length];
  const fileRef = useRef();

  useEffect(() => {
    document.body.style.overflow = cooking ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [cooking]);

  const toast = (msg) => { setSaveToast(msg); setTimeout(() => setSaveToast(""), 2400); };

  const getMeals = async () => {
    if (!ingredients.trim() && mode !== "expiring") { setError("Enter at least one ingredient!"); return; }
    if (mode === "expiring" && !expiring.trim()) { setError("Enter the ingredients going off!"); return; }
    setError(""); setLoading(true); setMeals(null); setExpanded(null);
    try {
      const res = await fetch("/api/meals", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ingredients, mode, diet, portions, expiring }),
      });
      const data = await res.json();
      if (data.error) throw new Error(data.error);
      setMeals(data.meals);
    } catch { setError("Something went wrong. Please try again."); }
    setLoading(false);
  };

  const handlePhoto = async (e) => {
    const file = e.target.files?.[0]; if (!file) return;
    setPhotoName(file.name); setPhotoLoading(true);
    await new Promise(r => setTimeout(r, 1800));
    setIngredients("chicken breast, eggs, cheddar cheese, spring onions, tomatoes, garlic");
    setPhotoLoading(false);
  };

  const toggleFav = (m) => {
    const exists = favourites.find(x => x.name === m.name);
    setFavourites(exists ? favourites.filter(x => x.name !== m.name) : [...favourites, m]);
    toast(exists ? "Removed from saved" : "✓ Saved — it'll be here next time!");
  };
  const isFav    = (m) => favourites.some(x => x.name === m.name);
  const addToShop = (m) => {
    const toAdd = (m.need || []).filter(i => !shopList.find(s => s.name === i));
    if (toAdd.length === 0) { toast("You already have everything!"); return; }
    setShopList([...shopList, ...toAdd.map(n => ({ name: n, checked: false, meal: m.name }))]);
    toast(`✓ ${toAdd.length} item${toAdd.length > 1 ? "s" : ""} added`);
    setTab("list");
  };
  const toggleShop = (i) => setShopList(shopList.map((s, j) => j === i ? { ...s, checked: !s.checked } : s));
  const assignDay  = (day) => {
    if (!planTarget) return;
    setPlanner({ ...planner, [day]: planTarget });
    setPlanTarget(null);
    toast(`✓ Added to ${day}`);
  };
  const rateMeal = (name, stars) => {
    setRatings({ ...ratings, [name]: stars });
    setStreak(streak + 1);
    toast(`✓ Rated! Streak: ${streak + 1} 🔥`);
  };
  const startCook = (meal) => setCooking({ meal, step: 0 });
  const nextStep  = () => {
    if (cooking.step < cooking.meal.steps.length - 1) setCooking(c => ({ ...c, step: c.step + 1 }));
    else setCooking(null);
  };

  const MealCard = ({ meal, idx, ns = "c" }) => {
    const key   = `${ns}-${idx}`;
    const open  = expanded === key;
    const rated = ratings[meal.name] || 0;
    return (
      <Card style={{ marginBottom: 12, overflow: "hidden", border: `1.5px solid ${open ? "#e8903a" : "#ede5d5"}`, transition: "border-color .2s", boxShadow: open ? "0 4px 20px #e8903a18" : "0 2px 12px #c8a97810", cursor: "default" }}>
        <div onClick={() => setExpanded(open ? null : key)} style={{ padding: "16px 16px 12px", cursor: "pointer" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
            <div style={{ flex: 1 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 5, flexWrap: "wrap" }}>
                <span style={{ fontSize: 10, color: "#a89070", background: "#f5ede0", padding: "2px 9px", borderRadius: 999, fontWeight: "600", letterSpacing: "1px", textTransform: "uppercase" }}>{meal.cuisine}</span>
                {rated > 0 && <Stars value={rated} />}
              </div>
              <h3 style={{ margin: "0 0 6px", fontSize: 17, color: "#2c1a0a", fontFamily: "'Lora',serif", fontWeight: "700", lineHeight: 1.3 }}>{meal.name}</h3>
              <div style={{ display: "flex", gap: 10, fontSize: 12, color: "#a89070", flexWrap: "wrap" }}>
                <span>⏱ {meal.time}</span><span>📊 {meal.difficulty}</span>
                <span>🔥 {meal.calories}</span><span>💪 {meal.protein} protein</span>
              </div>
            </div>
            <div style={{ width: 32, height: 32, borderRadius: "50%", background: open ? "#fef3e2" : "#f5ede0", border: `1.5px solid ${open ? "#e8903a" : "#ede5d5"}`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, marginLeft: 10, transition: "all .2s" }}>
              <span style={{ fontSize: 14, color: "#c17f3a", display: "inline-block", transform: open ? "rotate(45deg)" : "rotate(0deg)", transition: "transform .2s", lineHeight: 1 }}>+</span>
            </div>
          </div>
          <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginTop: 9 }}>
            {meal.tags?.map(t => <Tag key={t} label={t} />)}
          </div>
        </div>
        {open && (
          <div style={{ borderTop: "1px solid #f0e6d3", padding: "16px" }}>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 16 }}>
              <div style={{ background: "#f0fdf4", borderRadius: 14, padding: "12px" }}>
                <SLabel style={{ color: "#166534" }}>✓ You Have</SLabel>
                {(meal.have || []).map((i, j) => <div key={j} style={{ fontSize: 13, color: "#15803d", marginBottom: 4 }}>✓ {i}</div>)}
              </div>
              <div style={{ background: (meal.need || []).length === 0 ? "#f0fdf4" : "#fff7ed", borderRadius: 14, padding: "12px" }}>
                <SLabel style={{ color: (meal.need || []).length === 0 ? "#166534" : "#9a3412" }}>
                  {(meal.need || []).length === 0 ? "🎉 Nothing extra!" : "Just grab"}
                </SLabel>
                {(meal.need || []).length === 0
                  ? <div style={{ fontSize: 13, color: "#15803d" }}>You have everything!</div>
                  : (meal.need || []).map((i, j) => <div key={j} style={{ fontSize: 13, color: "#c2410c", marginBottom: 4 }}>+ {i}</div>)}
              </div>
            </div>
            <div style={{ background: "#fffbeb", border: "1px solid #fde68a", borderRadius: 12, padding: "10px 14px", marginBottom: 12 }}>
              <span style={{ fontSize: 12, color: "#92400e", fontWeight: "700" }}>✅ Full recipe below — no links, no Googling needed.</span>
            </div>
            {meal.funFact && (
              <div style={{ padding: "10px 14px", background: "#eff6ff", border: "1px solid #bfdbfe", borderRadius: 12, marginBottom: 12 }}>
                <span style={{ fontSize: 13, color: "#1e40af" }}>🌍 <strong>Did you know?</strong> {meal.funFact}</span>
              </div>
            )}
            {meal.tip && (
              <div style={{ padding: "10px 14px", background: "#fdf4ff", border: "1px solid #e9d5ff", borderRadius: 12, marginBottom: 16 }}>
                <span style={{ fontSize: 13, color: "#6b21a8" }}>💡 <strong>Tip:</strong> {meal.tip}</span>
              </div>
            )}
            <SLabel>How to make it — step by step</SLabel>
            <div style={{ marginBottom: 16 }}>
              {meal.steps?.map((step, j) => (
                <div key={j} style={{ display: "flex", gap: 12, marginBottom: 11, alignItems: "flex-start" }}>
                  <div style={{ minWidth: 26, height: 26, background: "linear-gradient(135deg,#e8903a,#c17f3a)", borderRadius: "50%", fontSize: 11, fontWeight: "bold", color: "#fff", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>{j + 1}</div>
                  <span style={{ fontSize: 14, color: "#4a3520", lineHeight: 1.65, paddingTop: 3 }}>{step}</span>
                </div>
              ))}
            </div>
            <div style={{ marginBottom: 14 }}>
              <SLabel>Rate this meal</SLabel>
              <Stars value={rated} onChange={s => rateMeal(meal.name, s)} />
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
              <button onClick={() => startCook(meal)} style={{ padding: "12px 8px", borderRadius: 12, border: "none", background: "linear-gradient(135deg,#e8903a,#c17f3a)", color: "#fff", fontSize: 13, fontWeight: "700", fontFamily: "inherit", cursor: "pointer" }}>👨‍🍳 Cook Mode</button>
              <button onClick={() => toggleFav(meal)} style={{ padding: "12px 8px", borderRadius: 12, fontFamily: "inherit", cursor: "pointer", border: isFav(meal) ? "1.5px solid #e8903a" : "1.5px solid #ede5d5", background: isFav(meal) ? "#fef3e2" : "#fff", color: isFav(meal) ? "#c17f3a" : "#9a8068", fontSize: 13 }}>{isFav(meal) ? "❤️ Saved" : "🤍 Save"}</button>
              <button onClick={() => addToShop(meal)} style={{ padding: "12px 8px", borderRadius: 12, border: "1.5px solid #ede5d5", background: "#fff", color: "#9a8068", fontSize: 13, fontFamily: "inherit", cursor: "pointer" }}>🛒 Shop List</button>
              <button onClick={() => { setPlanTarget(meal); setTab("planner"); }} style={{ padding: "12px 8px", borderRadius: 12, border: "1.5px solid #ede5d5", background: "#fff", color: "#9a8068", fontSize: 13, fontFamily: "inherit", cursor: "pointer" }}>📅 Plan It</button>
            </div>
          </div>
        )}
      </Card>
    );
  };

  if (cooking) {
    const { meal, step } = cooking;
    const total = meal.steps.length;
    const pct   = ((step + 1) / total) * 100;
    return (
      <div style={{ position: "fixed", inset: 0, background: "#fdf8f0", display: "flex", flexDirection: "column", fontFamily: "'Georgia',serif", color: "#2c1a0a", zIndex: 999 }}>
        <div style={{ height: 4, background: "#ede5d5" }}>
          <div style={{ height: "100%", width: `${pct}%`, background: "linear-gradient(90deg,#e8903a,#c17f3a)", transition: "width .4s ease" }} />
        </div>
        <div style={{ padding: "16px 20px 0", display: "flex", justifyContent: "space-between" }}>
          <button onClick={() => setCooking(null)} style={{ background: "none", border: "none", color: "#a89070", fontSize: 14, cursor: "pointer", fontFamily: "inherit" }}>✕ Exit</button>
          <span style={{ fontSize: 13, color: "#a89070" }}>Step {step + 1} of {total}</span>
        </div>
        <div style={{ flex: 1, display: "flex", flexDirection: "column", justifyContent: "center", padding: "20px 24px 0" }}>
          <div style={{ fontSize: 12, color: "#a89070", marginBottom: 10, letterSpacing: "1px", textTransform: "uppercase" }}>👨‍🍳 {meal.name}</div>
          <div style={{ fontSize: "clamp(20px,5vw,30px)", lineHeight: 1.55, color: "#2c1a0a", fontFamily: "'Lora',serif", fontWeight: 700, marginBottom: 28 }}>{meal.steps[step]}</div>
          <Card style={{ padding: "14px 16px", marginBottom: 20 }}>
            <SLabel>Ingredients</SLabel>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
              {[...(meal.have || []), ...(meal.need || [])].map((i, j) => (
                <span key={j} style={{ fontSize: 12, color: "#7a6048", background: "#f5ede0", padding: "4px 10px", borderRadius: 999, border: "1px solid #ede5d5" }}>{i}</span>
              ))}
            </div>
          </Card>
        </div>
        <div style={{ padding: "0 24px 44px" }}>
          <button onClick={nextStep} style={{ width: "100%", padding: "19px", background: "linear-gradient(135deg,#e8903a,#c17f3a)", border: "none", borderRadius: 16, color: "#fff", fontSize: 17, fontWeight: "700", fontFamily: "inherit", cursor: "pointer" }}>
            {step < total - 1 ? "Next Step →" : "✅ I'm done!"}
          </button>
        </div>
      </div>
    );
  }

  const NAV = [
    { id: "find",       icon: "🍳", label: "Find" },
    { id: "favourites", icon: "❤️",  label: "Saved" },
    { id: "planner",    icon: "📅", label: "Plan" },
    { id: "list",       icon: "🛒", label: "Shop" },
    { id: "explore",    icon: "🌍", label: "Explore" },
  ];

  return (
    <div style={{ minHeight: "100vh", background: "#fdf8f0", fontFamily: "'Georgia',serif", color: "#2c1a0a", paddingBottom: 88 }}>
      <style>{`
        @keyframes spin    { to { transform: rotate(360deg) } }
        @keyframes fadeUp  { from { opacity:0; transform:translateY(14px) } to { opacity:1; transform:translateY(0) } }
        @keyframes slideUp { from { opacity:0; transform:translateY(30px) } to { opacity:1; transform:translateY(0) } }
        .fu { animation: fadeUp .35s ease both }
        * { box-sizing: border-box }
        textarea, input { outline: none }
        button { cursor: pointer }
        button:active { opacity: .85 }
      `}</style>

      {saveToast && (
        <div style={{ position: "fixed", bottom: 100, left: "50%", transform: "translateX(-50%)", background: "#2c1a0a", color: "#fff", padding: "10px 20px", borderRadius: 999, fontSize: 13, zIndex: 900, whiteSpace: "nowrap", animation: "slideUp .25s ease", boxShadow: "0 4px 16px #00000030" }}>
          {saveToast}
        </div>
      )}

      {/* Header */}
      <div style={{ background: "#fff", borderBottom: "1px solid #ede5d5", boxShadow: "0 2px 20px #1e120a0a" }}>
        <div style={{ background: "#1e120a", padding: "18px 20px 16px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
            <Logo size={62} />
            <div>
              <h1 style={{ fontFamily: "'Lora',serif", fontSize: "clamp(18px,5vw,26px)", fontWeight: 700, margin: "0 0 3px", color: "#fff", letterSpacing: "-0.3px" }}>What's for Dinner?</h1>
              <p style={{ color: "#c17f3a", fontSize: 11, margin: 0, letterSpacing: "1.5px", textTransform: "uppercase", fontWeight: "600" }}>All meals · sorted</p>
            </div>
          </div>
          <div style={{ display: "flex", flexDirection: "column", alignItems: "center", background: "#2c1a0a", border: "1.5px solid #c17f3a", borderRadius: 12, padding: "6px 12px", minWidth: 52 }}>
            <span style={{ fontSize: 20, lineHeight: 1 }}>🔥</span>
            <span style={{ fontSize: 13, color: "#e8903a", fontWeight: "700" }}>{streak}</span>
            <span style={{ fontSize: 9, color: "#8a6040", letterSpacing: "1px", textTransform: "uppercase" }}>streak</span>
          </div>
        </div>
        <div style={{ padding: "8px 20px", background: "#faf7f2", borderTop: "1px solid #f0e8d8", display: "flex", alignItems: "center", gap: 6 }}>
          <span style={{ fontSize: 12 }}>☁️</span>
          <span style={{ fontSize: 12, color: "#15803d", fontWeight: "600" }}>Your favourites, planner & shopping list auto-save — they never disappear</span>
        </div>
      </div>

      <div style={{ maxWidth: 600, margin: "0 auto", padding: "0 16px" }}>

        {/* FIND */}
        {tab === "find" && (
          <div className="fu">
            <div style={{ marginTop: 20, padding: "12px 16px", background: "#f0fdf4", border: "1.5px solid #bbf7d0", borderRadius: 14, display: "flex", alignItems: "flex-start", gap: 10 }}>
              <span style={{ fontSize: 20, flexShrink: 0 }}>✅</span>
              <div style={{ fontSize: 13, color: "#15803d", lineHeight: 1.6 }}>
                <strong>No ingredient bait-and-switch.</strong> We only suggest meals using what <em>you</em> have. Full recipes — no links to other sites.
              </div>
            </div>

            <div style={{ marginTop: 14, padding: "13px 16px", background: "#fff", border: "1.5px dashed #e8d5b0", borderRadius: 16, display: "flex", alignItems: "center", gap: 12, cursor: "pointer" }} onClick={() => fileRef.current.click()}>
              <span style={{ fontSize: 24 }}>📸</span>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 14, fontWeight: "700", color: "#2c1a0a", fontFamily: "'Lora',serif" }}>Scan Your Fridge</div>
                <div style={{ fontSize: 12, color: "#a89070" }}>{photoLoading ? "🔍 Detecting…" : photoName ? "✓ Detected from photo" : "Upload a photo — AI reads what you have"}</div>
              </div>
              {photoLoading ? <div style={{ width: 18, height: 18, border: "2px solid #ede5d5", borderTop: "2px solid #e8903a", borderRadius: "50%", animation: "spin 1s linear infinite" }} /> : <span style={{ fontSize: 18, color: "#c17f3a" }}>→</span>}
            </div>
            <input ref={fileRef} type="file" accept="image/*" style={{ display: "none" }} onChange={handlePhoto} />

            <div style={{ marginTop: 18 }}>
              <SLabel>Your Mode</SLabel>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 9 }}>
                {MODES.map(m => (
                  <button key={m.id} onClick={() => setMode(m.id)} style={{ background: mode === m.id ? "#fff7ed" : "#fff", border: `1.5px solid ${mode === m.id ? "#e8903a" : "#ede5d5"}`, borderRadius: 14, padding: "13px 12px", cursor: "pointer", textAlign: "left", fontFamily: "inherit", transition: "all .18s", boxShadow: mode === m.id ? "0 2px 10px #e8903a18" : "none" }}>
                    <div style={{ fontSize: 20, marginBottom: 4 }}>{m.emoji}</div>
                    <div style={{ fontSize: 13, fontWeight: "700", color: mode === m.id ? "#c17f3a" : "#2c1a0a", fontFamily: "'Lora',serif" }}>{m.label}</div>
                    <div style={{ fontSize: 11, color: "#a89070", marginTop: 2 }}>{m.desc}</div>
                  </button>
                ))}
              </div>
            </div>

            {mode === "expiring" && (
              <div style={{ marginTop: 14 }}>
                <SLabel>⚠️ What's expiring soon?</SLabel>
                <input value={expiring} onChange={e => setExpiring(e.target.value)} placeholder="e.g. spinach, yogurt, chicken mince…" style={{ width: "100%", background: "#fff", border: "1.5px solid #fde68a", borderRadius: 12, padding: "12px 14px", color: "#2c1a0a", fontSize: 14, fontFamily: "inherit" }} />
              </div>
            )}

            <div style={{ marginTop: 16 }}>
              <SLabel>Dietary Needs</SLabel>
              <div style={{ display: "flex", gap: 7, flexWrap: "wrap" }}>
                {DIETS.map(d => <PillBtn key={d} active={diet === d} onClick={() => setDiet(d)}>{d}</PillBtn>)}
              </div>
            </div>

            <div style={{ marginTop: 16 }}>
              <SLabel>Cooking for how many?</SLabel>
              <div style={{ display: "flex", gap: 8 }}>
                {PORTIONS.map(p => (
                  <button key={p} onClick={() => setPortions(p)} style={{ width: 44, height: 44, borderRadius: 10, fontFamily: "inherit", border: `1.5px solid ${portions === p ? "#e8903a" : "#ede5d5"}`, background: portions === p ? "#fff7ed" : "#fff", color: portions === p ? "#c17f3a" : "#9a8068", fontSize: 15, fontWeight: "700", boxShadow: portions === p ? "0 2px 8px #e8903a18" : "none", transition: "all .18s" }}>{p}</button>
                ))}
              </div>
            </div>

            <div style={{ marginTop: 16 }}>
              <SLabel>Your Ingredients</SLabel>
              <textarea value={ingredients} onChange={e => setIngredients(e.target.value)} placeholder="e.g. chicken, rice, eggs, cheese, garlic, onion…" rows={3}
                onFocus={e => e.target.style.borderColor = "#e8903a"}
                onBlur={e => e.target.style.borderColor = "#ede5d5"}
                style={{ width: "100%", background: "#fff", border: "1.5px solid #ede5d5", borderRadius: 14, padding: "13px 15px", color: "#2c1a0a", fontSize: 15, fontFamily: "inherit", resize: "none", transition: "border-color .2s" }} />
              {error && <p style={{ color: "#dc2626", fontSize: 13, margin: "6px 0 0" }}>{error}</p>}
            </div>

            <button onClick={getMeals} disabled={loading} style={{ width: "100%", marginTop: 14, padding: "17px", background: loading ? "#f5ede0" : "linear-gradient(135deg,#e8903a,#c17f3a)", border: "none", borderRadius: 14, color: loading ? "#c8a978" : "#fff", fontSize: 16, fontWeight: "700", fontFamily: "'Lora',serif", cursor: loading ? "not-allowed" : "pointer", boxShadow: loading ? "none" : "0 4px 16px #e8903a35", transition: "all .2s" }}>
              {loading ? "🍳 Finding 6 meals for you…" : "✨ What's for Dinner?"}
            </button>

            {loading && (
              <div style={{ textAlign: "center", marginTop: 24 }}>
                <div style={{ width: 36, height: 36, border: "3px solid #ede5d5", borderTop: "3px solid #e8903a", borderRadius: "50%", margin: "0 auto 10px", animation: "spin 1s linear infinite" }} />
                <p style={{ color: "#a89070", fontSize: 13, fontStyle: "italic" }}>Picking 6 meals using your ingredients…</p>
              </div>
            )}

            {meals && (
              <div style={{ marginTop: 22 }} className="fu">
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
                  <SLabel style={{ marginBottom: 0 }}>{meals.length} Recipes Found</SLabel>
                  <span style={{ fontSize: 12, color: "#a89070" }}>for {portions} person{portions > 1 ? "s" : ""}</span>
                </div>
                {meals.map((m, i) => <MealCard key={i} meal={m} idx={i} ns="find" />)}
                <button onClick={() => { setMeals(null); setIngredients(""); setExpiring(""); }} style={{ width: "100%", marginTop: 4, padding: "13px", background: "#fff", border: "1.5px solid #ede5d5", borderRadius: 14, color: "#a89070", fontSize: 14, fontFamily: "inherit" }}>↩ Start Over</button>
              </div>
            )}
          </div>
        )}

        {/* FAVOURITES */}
        {tab === "favourites" && (
          <div className="fu" style={{ marginTop: 22 }}>
            <SLabel>Saved Meals ({favourites.length})</SLabel>
            {!favReady ? <div style={{ textAlign: "center", padding: 40, color: "#a89070" }}>Loading…</div>
              : favourites.length === 0
                ? <Card style={{ textAlign: "center", padding: "48px 20px" }}>
                    <div style={{ fontSize: 44, marginBottom: 12 }}>🤍</div>
                    <div style={{ fontSize: 16, fontFamily: "'Lora',serif", color: "#2c1a0a" }}>No saved meals yet</div>
                    <div style={{ fontSize: 13, color: "#a89070", marginTop: 6 }}>Find a meal and tap Save</div>
                  </Card>
                : favourites.map((m, i) => <MealCard key={i} meal={m} idx={i} ns="fav" />)
            }
          </div>
        )}

        {/* PLANNER */}
        {tab === "planner" && (
          <div className="fu" style={{ marginTop: 22 }}>
            <SLabel>Weekly Meal Planner</SLabel>
            {planTarget && (
              <div style={{ padding: "10px 14px", background: "#fff7ed", border: "1.5px solid #fde68a", borderRadius: 12, marginBottom: 14, fontSize: 14, color: "#92400e" }}>
                📌 Assigning <strong>{planTarget.name}</strong> — tap a day
              </div>
            )}
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              {DAYS.map(day => {
                const a = planner[day];
                return (
                  <Card key={day} onClick={() => planTarget && assignDay(day)} style={{ padding: "13px 16px", cursor: planTarget ? "pointer" : "default", border: planTarget ? "1.5px solid #fde68a" : "1.5px solid #ede5d5", display: "flex", alignItems: "center", gap: 12, transition: "all .2s" }}>
                    <span style={{ width: 38, fontSize: 13, fontWeight: "700", color: planTarget ? "#c17f3a" : "#a89070", fontFamily: "'Lora',serif" }}>{day}</span>
                    {a ? (
                      <div style={{ flex: 1 }}>
                        <div style={{ fontSize: 14, color: "#2c1a0a", fontFamily: "'Lora',serif" }}>{a.name}</div>
                        <div style={{ fontSize: 11, color: "#a89070" }}>⏱ {a.time} · {a.difficulty} · {a.calories}</div>
                      </div>
                    ) : <span style={{ flex: 1, fontSize: 13, color: "#ddd0bc" }}>— not planned —</span>}
                    {a && <button onClick={e => { e.stopPropagation(); const n = { ...planner }; delete n[day]; setPlanner(n); }} style={{ background: "none", border: "none", color: "#c8a978", fontSize: 16, padding: 4 }}>✕</button>}
                  </Card>
                );
              })}
            </div>
            <button onClick={() => setPlanner({})} style={{ width: "100%", marginTop: 14, padding: "13px", background: "#fff", border: "1.5px solid #ede5d5", borderRadius: 14, color: "#a89070", fontSize: 14, fontFamily: "inherit" }}>Clear Week</button>
          </div>
        )}

        {/* SHOP */}
        {tab === "list" && (
          <div className="fu" style={{ marginTop: 22 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
              <SLabel style={{ marginBottom: 0 }}>Shopping List ({shopList.filter(s => !s.checked).length} left)</SLabel>
              <div style={{ display: "flex", gap: 10 }}>
                <span style={{ fontSize: 12, color: "#15803d" }}>☁️ Auto-saved</span>
                {shopList.length > 0 && <button onClick={() => setShopList([])} style={{ background: "none", border: "none", color: "#a89070", fontSize: 13, fontFamily: "inherit" }}>Clear all</button>}
              </div>
            </div>
            {shopList.length === 0
              ? <Card style={{ textAlign: "center", padding: "48px 20px" }}>
                  <div style={{ fontSize: 44, marginBottom: 12 }}>🛒</div>
                  <div style={{ fontSize: 16, fontFamily: "'Lora',serif", color: "#2c1a0a" }}>Your list is empty</div>
                  <div style={{ fontSize: 13, color: "#a89070", marginTop: 6 }}>Find a meal → tap "Shop List"</div>
                </Card>
              : <>
                  {[...new Set(shopList.map(s => s.meal))].map(mealName => (
                    <div key={mealName} style={{ marginBottom: 16 }}>
                      <div style={{ fontSize: 11, letterSpacing: "1.5px", color: "#a89070", textTransform: "uppercase", fontWeight: "700", marginBottom: 8 }}>{mealName}</div>
                      {shopList.filter(s => s.meal === mealName).map(item => {
                        const gi = shopList.indexOf(item);
                        return (
                          <Card key={gi} onClick={() => toggleShop(gi)} style={{ display: "flex", alignItems: "center", gap: 12, padding: "12px 14px", marginBottom: 7 }}>
                            <div style={{ width: 22, height: 22, borderRadius: 7, border: `2px solid ${item.checked ? "#16a34a" : "#e8d5b0"}`, background: item.checked ? "#16a34a" : "#fff", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, transition: "all .2s" }}>
                              {item.checked && <span style={{ color: "#fff", fontSize: 12, fontWeight: "bold" }}>✓</span>}
                            </div>
                            <span style={{ fontSize: 15, color: item.checked ? "#a89070" : "#2c1a0a", textDecoration: item.checked ? "line-through" : "none", transition: "all .2s" }}>{item.name}</span>
                          </Card>
                        );
                      })}
                    </div>
                  ))}
                  {shopList.some(s => s.checked) && (
                    <button onClick={() => setShopList(shopList.filter(s => !s.checked))} style={{ width: "100%", marginTop: 4, padding: "13px", background: "#fff", border: "1.5px solid #ede5d5", borderRadius: 14, color: "#a89070", fontSize: 14, fontFamily: "inherit" }}>Remove ticked items</button>
                  )}
                </>
            }
          </div>
        )}

        {/* EXPLORE */}
        {tab === "explore" && (
          <div className="fu" style={{ marginTop: 22 }}>
            <div style={{ background: "linear-gradient(135deg,#fff7ed,#fef3e2)", border: "1.5px solid #fde68a", borderRadius: 20, padding: "20px", marginBottom: 20 }}>
              <SLabel style={{ color: "#c17f3a" }}>🌍 Cuisine of the Week</SLabel>
              <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 12 }}>
                <span style={{ fontSize: 52, lineHeight: 1 }}>{cuisine.flag}</span>
                <div>
                  <div style={{ fontSize: 24, fontFamily: "'Lora',serif", fontWeight: 700, color: "#2c1a0a" }}>{cuisine.name}</div>
                  <div style={{ fontSize: 14, color: "#a89070" }}>Try: <em>{cuisine.dish}</em></div>
                </div>
              </div>
              <div style={{ fontSize: 13, color: "#92400e", fontStyle: "italic", lineHeight: 1.6, borderTop: "1px solid #fde68a", paddingTop: 10 }}>💡 {cuisine.fact}</div>
              <button onClick={() => { setIngredients(""); setMode("normal"); setTab("find"); }} style={{ marginTop: 14, width: "100%", padding: "12px", background: "linear-gradient(135deg,#e8903a,#c17f3a)", border: "none", borderRadius: 12, color: "#fff", fontSize: 14, fontFamily: "'Lora',serif", fontWeight: "700", cursor: "pointer" }}>
                Find {cuisine.name} Recipes →
              </button>
            </div>
            <SLabel>Explore All Cuisines</SLabel>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 24 }}>
              {CUISINES.map(c => (
                <Card key={c.name} onClick={() => { setIngredients(""); setMode("normal"); setTab("find"); }} style={{ padding: "14px 12px" }}>
                  <div style={{ fontSize: 30, marginBottom: 6 }}>{c.flag}</div>
                  <div style={{ fontSize: 14, fontWeight: "700", color: "#2c1a0a", fontFamily: "'Lora',serif" }}>{c.name}</div>
                  <div style={{ fontSize: 11, color: "#a89070", marginTop: 2 }}>{c.dish}</div>
                </Card>
              ))}
            </div>
            <SLabel>Beginner Cooking Tips</SLabel>
            {[
              { t: "Always read the whole recipe before you start cooking.", i: "📖" },
              { t: "Prep all your ingredients before you turn on the heat.", i: "🔪" },
              { t: "Taste as you go and season little by little.", i: "🧂" },
              { t: "Medium heat is almost always safer than high heat.", i: "🔥" },
              { t: "A sharp knife is actually safer than a blunt one.", i: "⚡" },
              { t: "Let meat rest 5 minutes after cooking — it stays much juicier.", i: "⏱" },
            ].map((t, i) => (
              <Card key={i} style={{ display: "flex", gap: 12, padding: "13px 14px", marginBottom: 8 }}>
                <span style={{ fontSize: 20 }}>{t.i}</span>
                <span style={{ fontSize: 14, color: "#4a3520", lineHeight: 1.55 }}>{t.t}</span>
              </Card>
            ))}
          </div>
        )}
      </div>

      {/* Bottom Nav */}
      <div style={{ position: "fixed", bottom: 0, left: 0, right: 0, background: "#fff", borderTop: "1px solid #ede5d5", display: "flex", padding: "8px 0 16px", boxShadow: "0 -4px 20px #c8a97812" }}>
        {NAV.map(n => (
          <button key={n.id} onClick={() => setTab(n.id)} style={{ flex: 1, background: "none", border: "none", display: "flex", flexDirection: "column", alignItems: "center", gap: 3, padding: "4px 0", fontFamily: "inherit" }}>
            <span style={{ fontSize: 21, filter: tab === n.id ? "none" : "grayscale(1) opacity(.4)", transition: "filter .2s" }}>{n.icon}</span>
            <span style={{ fontSize: 10, letterSpacing: "1px", textTransform: "uppercase", color: tab === n.id ? "#c17f3a" : "#c8b89a", fontWeight: tab === n.id ? "700" : "400", transition: "color .2s" }}>{n.label}</span>
          </button>
        ))}
      </div>
    </div>
  );
}
