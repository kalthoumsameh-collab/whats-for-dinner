// app/api/meals/route.js
// This runs on the SERVER — your API key stays secret here

export async function POST(request) {
  const { ingredients, mode, diet, portions, expiring } = await request.json();

  const modeMap = {
    normal:   "Suggest varied, delicious meals from many different cuisines.",
    broke:    "Suggest very cheap meals under £3, using Aldi/Lidl-style budget ingredients.",
    noenergy: "Suggest meals that take under 10 minutes with minimal steps and washing up.",
    gym:      "Suggest high-protein meals for muscle gain or fat loss.",
    expiring: `PRIORITY: user must use these expiring ingredients: ${expiring}. Build meals around them.`,
  };

  const dietNote    = diet !== "None" ? `STRICT: every meal must be ${diet} compliant.` : "";
  const portionNote = `Scale all amounts for exactly ${portions} person${portions > 1 ? "s" : ""}.`;

  const prompt = `You are a warm, encouraging AI chef called "What's for Dinner?".

CRITICAL RULES — follow exactly:
1. ONLY suggest meals using the ingredients the user listed. Do NOT require major ingredients they haven't mentioned.
2. The "need" array should only contain small extras like salt, oil, herbs, spices — NOT main ingredients.
3. Every recipe must be complete and self-contained — full steps, no links, no "see online".
4. Use plain English. Never say "sauté", "fold in", "deglaze", "blanch". Say what you mean simply.
5. Be warm and encouraging in the step descriptions.

User has: ${ingredients || "basic pantry staples (flour, oil, salt, eggs)"}.
Mode: ${modeMap[mode] || modeMap.normal}
${dietNote} ${portionNote}

Return EXACTLY 6 diverse meal ideas as a JSON array. Each object:
- name: string
- cuisine: string (e.g. "Italian", "Mexican", "British", "Indian", "Thai")
- time: string (e.g. "20 mins")
- difficulty: "Easy" | "Medium" | "Hard"
- calories: string (e.g. "~420 kcal per serving")
- protein: string (e.g. "32g")
- tags: array of 1–3 from ["💸 Budget","⚡ Quick","💪 High Protein","🌱 Vegan","🕌 Halal","🚫 Gluten-Free","🌍 World","🔥 Spicy"]
- have: string[] — ingredients from the user's list used in this meal
- need: string[] — ONLY small extras like oil, salt, pepper, herbs. Empty [] if none.
- steps: string[] of 4–6 plain-English, encouraging, beginner-friendly steps. Full instructions.
- tip: string — one genuinely useful beginner tip
- funFact: string — one fun fact about this dish or its cuisine

Return ONLY the raw JSON array. No markdown, no explanation.`;

  try {
    const response = await fetch("https://api.groq.com/openai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${process.env.GROQ_API_KEY}`,
      },
      body: JSON.stringify({
        model: "llama-3.3-70b-versatile",
        max_tokens: 2800,
        temperature: 0.7,
        messages: [{ role: "user", content: prompt }],
      }),
    });

    if (!response.ok) {
      const err = await response.text();
      console.error("Groq error:", err);
      return Response.json({ error: "API error" }, { status: 500 });
    }

    const data = await response.json();
    const text = data.choices[0].message.content;
    const meals = JSON.parse(text.replace(/```json|```/g, "").trim());

    return Response.json({ meals });
  } catch (err) {
    console.error("Server error:", err);
    return Response.json({ error: "Something went wrong" }, { status: 500 });
  }
}
